#include <stdio.h>
#include <string.h>

void main(void) {
char c;
char b[3];
char s[20];
int i;
float f;

char *pc = NULL;
char *ps = NULL;
int *pi = NULL;
float *pf = NULL;

printf("Write a character.\n");
fgets(b, 3, stdin);
c = b[0];

printf("Write a string within 20 characters.\n");
fgets(s, 20, stdin);
strtok(s, "\n");

printf("Enter an integer.\n");
scanf("%d", &i);

printf("Enter a floating point number.\n");
scanf("%fl", &f);

pc = &c;
ps = s;
pi = &i;
pf = &f;

printf("\nCharacter: %c\n", *pc);
printf("Integer: %d\n", *pi);
printf("String: %s\n", ps);
printf("Floating Point: %fl\n", *pf);

printf("\nCharacter Pointer: %p\n", pc);
printf("Integer Pointer: %p\n", pi);
printf("String Pointer: %p\n", &ps);
printf("Floating Point Pointer: %p\n", pf);
}
