#include <stdio.h>
#include <string.h>
#include "studentStruct.h"

void printStudent(Student s) {
	printf("First Name: \"%s\"\n", s.firstName);
	printf("Last Name: \"%s\"\n", s.lastName);
	printf("ID: \"%s\"\n", s.id);
	printf("Month: %d\n", s.dob.month);
	printf("Day: %s\n", s.dob.day);
	printf("Year: %d\n", s.dob.year);
	printf("Class: %d\n", s.class);
	printf("GPA: %0.2f\n", s.gpa);
}