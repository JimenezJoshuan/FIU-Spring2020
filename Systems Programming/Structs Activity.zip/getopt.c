#include <stdio.h>
#include <stdlib.h>
#include "studentStruct.h"

int debug = 0;

int
main(int argc, char **argv)
{
	extern char *optarg;
	extern int optind;
	int c,  err = 0;
	int iflag = 0, mflag = 0, dflag = 0, yflag = 0, cflag = 0, gflag = 0;
	int month, year, class = 1;
	char *id, *day;
	float gpa = 3.00;
	static char usage[] = "Command: $ studentstruct -i studentid -m month -d day -y year [-c] class [-g] gpa FirstName LastName\n";

	while ((c = getopt(argc, argv, "i:m:d:y:c:g:")) != -1)
		switch (c) {
		case 'i':
		  iflag = 1;
		  id = optarg;
		  break;
		case 'm':
		  mflag = 1;
		  month = atoi(optarg);
		  break;
		case 'd':
		  dflag = 1;
		  day = optarg;
		  break;
		case 'y':
		  yflag = 1;
		  year = atoi(optarg);
		  break;
		case 'c':
		  cflag = 1;
		  class = atoi(optarg);
		  break;
		case 'g':
		  gflag = 1;
		  gpa = atof(optarg);
		  break;
		case '?':
		  err = 1;
		  break;
		case ':':
		  err = 1;
		  break;
		}
	if (iflag == 0) {	/* -i was mandatory */
	  fprintf(stderr, "%s: missing -i option\n", argv[0]);
	  fprintf(stderr, usage, argv[0]);
	  exit(1);
	}
	else if (mflag == 0) {  /* -m was mandatory */
	  fprintf(stderr, "%s: missing -m option\n", argv[0]);
	  fprintf(stderr, usage, argv[0]);
	  exit(1);
	}
	else if (dflag == 0) {	/* -d was mandatory */
	  fprintf(stderr, "%s: missing -d option\n", argv[0]);
	  fprintf(stderr, usage, argv[0]);
	  exit(1);
	}
	else if (yflag == 0) {	/* -y was mandatory */
	  fprintf(stderr, "%s: missing -y option\n", argv[0]);
	  fprintf(stderr, usage, argv[0]);
	  exit(1);
	}
	else if ((optind + 2) > argc) {	
		/* need at least two arguments */

		printf("optind = %d, argc=%d\n", optind, argc);
		fprintf(stderr, "%s: Missing name\n", argv[0]);
		fprintf(stderr, usage, argv[0]);
		exit(1);
	}
	else if (err) {
		fprintf(stderr, usage, argv[0]);
		exit(1);
	}

	DateofBirth dob;
	dob.month = month;
	dob.day = day;
	dob.year = year;
	
	Student s;
	s.id = id;
	s.class = class;
	s.gpa = gpa;
	s.dob = dob;
	
	if (optind < argc) {	
		s.firstName = argv[argc - 2];
		s.lastName = argv[argc - 1];		
	}

	printStudent(s);
	
	exit(0);
}
