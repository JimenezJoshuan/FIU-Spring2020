typedef struct DateofBirth_struct {
  int month;
  char *day;
  int year;
}DateofBirth;

typedef struct Student_struct {
  char *firstName;
  char *lastName;
  char *id;
  int class;
  float gpa;
  DateofBirth dob;
}Student;

void printStudent(Student s);