#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void lower(char* s) {
  int i;

  for(i = 0; s[i] != '\0'; i++) {
    s[i] = tolower(s[i]);
  }
}

void upper(char* s) {
  int i;

  for(i = 0; s[i] != '\0'; i++) {
    s[i] = toupper(s[i]);
  }
}

int countWords(const char* s) {
  if(strlen(s) == 0) {
    return 0;
  }
  char c = '\0';
  char p = '\0';

  int i = 0;

  int nw = 0;
  int efc = 0;

  for(i = 0; s[i] != '\0'; i++) {
    c = s[i];

    if(c != ' ' && p == ' ' && efc == 1) {
      ++nw;
    }

    if(c != ' ') {
      efc = 1;
    }
    p = c;
  }
  ++nw;
  return nw;
}

int validateInput(const char* s) {
  int nc = strlen(s);
  if(nc > 80) {
    return -1;
  }

  int nw = countWords(s);
  if(nw < 3 || nw > 10) {
    return -1;
  }
  return 0;
}

int main(int argc, char **argv) {

  extern char* optarg;
  extern int optind;

  int c, err = 0;
  int lflag = 0, uflag = 0, fflag = 0;
  char* fname;
  static const char name[] = "Joshuan Jimenez";
  char* myname = (char*)malloc(strlen(name) * sizeof(char));
  strcpy(myname, name);

  static char usage[] = "Usage: %s [-lu] [-f filename] \"argument string\"\n";

  while((c = getopt(argc, argv, "luf:")) != -1) {
    switch(c) {
      case 'l' :
        lflag = 1;
        break;
      case 'u' :
        uflag = 1;
        break;
      case 'f' :
        fflag = 1;
        fname = optarg;
        break;
      case '?' :
        err = 1;
        break;
      case ':' :
	err = 1;
	break;
    }
  }

  if(err == 1) {
    fprintf(stderr, "%s: Error has occurred.\n", argv[0]);
    fprintf(stderr, usage, argv[0]);
    exit(1);
  }

  else if(lflag == 1 && uflag == 1) {
    fprintf(stderr, "%s: Cannot use both -l and -u options.\n", argv[0]);
    fprintf(stderr, usage, argv[0]);
		exit(1);
  }

  else if(optind == argc) {
    fprintf(stderr, "%s: Missing \"argument string\"\n", argv[0]);
    fprintf(stderr, usage, argv[0]);
    exit(1);
  }

  int valid = validateInput(argv[optind]);

  if(valid == -1) {
    fprintf(stderr, "%s: \"argument string\" does not meet the bounds of 3 - 10 words and 80 characters max.\n", argv[0]);
    exit(1);
  }

  if(lflag == 1) {
    lower(myname);
    lower(argv[optind]);
  } 
  
  if(uflag == 1) {
    upper(myname);
    upper(argv[optind]);
  }

  if(fflag == 1) {
    FILE* output = NULL;
    output = fopen(fname, "w");

    if(output == NULL) {
      perror("Error opening file: ");
      exit(1);
    }
    fprintf(output, "%s %s\n", myname, argv[optind]);
    printf("Successfully wrote to %s.\n", fname);
    fclose(output);
  } 
  else {
    printf("%s %s\n", myname, argv[optind]);
  }
  return 0;
}
