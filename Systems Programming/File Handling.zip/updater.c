#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int countWords(const char* s) {
  if(strlen(s) == 0) {
    return 0;
  }
  char c = '\0';
  char p = '\0';

  int i = 0;

  int nw = 0;
  int efc = 0;

  for(i = 0; s[i] != '\0'; i++) {
    c = s[i];

    if(c != ' ' && p == ' ' && efc == 1) {
      ++nw;
    }

    if(c != ' ') {
      efc = 1;
    }
    p = c;
  }
  ++nw;
  return nw;
}

int main(int argc, char **argv) {
  extern char* optarg;
  extern int optind;

  int c, err = 0;
  int fflag = 0;
  char* fname;

  static char usage[] = "Usage: %s -f filename \"argument string\"\n";

  while((c = getopt(argc, argv, "f:")) != -1) {
    switch(c) {
      case 'f' :
        fflag = 1;
        fname = optarg;
        break;
      case '?' :
        err = 1;
        break;
      case ':' :
	err = 1;
	break;
    }  
  }

  if(err == 1) {
    fprintf(stderr, "%s: Error has occurred.\n", argv[0]);
    fprintf(stderr, usage, argv[0]);
    exit(1);
  }

  if(fflag == 0) {
    fprintf(stderr, "%s: Missing required option -f\n", argv[0]);
    fprintf(stderr, usage, argv[0]);
    exit(1);
  }

  int nw = countWords(argv[optind]);

  if(nw != 5) {
    fprintf(stderr, "%s: \"argument string\" needs to be 5 words.\n", argv[0]);
    exit(1);
  }

  FILE* output = NULL;
  output = fopen(fname, "a");

  if(output == NULL) {
    perror("Error opening file: ");
    exit(1);
  }

  fprintf(output, "%s\n", argv[optind]);
  printf("Successfully appended to %s.\n", fname);
  fclose(output);
  return 0;
}