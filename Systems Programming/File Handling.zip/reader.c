#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(int argc, char **argv) {
  extern char* optarg;
  extern int optind;

  int c, err = 0;
  int fflag = 0;
  char* fname;

  static char usage[] = "Usage: %s -f filename\n";

  while((c = getopt(argc, argv, "f:")) != -1) {
    switch(c) {
      case 'f' :
        fflag = 1;
        fname = optarg;
        break;
      case '?' :
        err = 1;
        break;
      case ':' :
	err = 1;
	break;
    }  
  }

  if(err == 1) {
    fprintf(stderr, "%s: Error has occurred.\n", argv[0]);
    fprintf(stderr, usage, argv[0]);
    exit(1);
  }

  if(fflag == 0) {
    fprintf(stderr, "%s: Missing required option -f\n", argv[0]);
    fprintf(stderr, usage, argv[0]);
    exit(1);
  }

  FILE* input = NULL;

  input = fopen(fname, "r");

  if (input == NULL) {
    perror("Error opening file: ");
    printf("Please make sure you created \"%s\" using updater.\n", fname);
    exit(1);
  }

  printf("Opening file \"%s\"\n", fname);

  char lineBuffer[150];
  fgets(lineBuffer, 150, input);

  char strings[5][150];

  int n = sscanf(lineBuffer, "%s %s %s %s %s", strings[0], strings[1], strings[2], strings[3], strings[4]);

  if(n == 5) {
    int i = 0;

    for(; i < 5; ++i) {
      printf("File Sentence 1 word %d = %s\n", i + 1, strings[i]);
    }

  } else {
    printf("First line of \"%s\" does not have 5 words.\n", fname);
    exit(1);
  }

  fclose(input);

  return 0;
}